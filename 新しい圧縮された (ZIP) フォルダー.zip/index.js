import express from "express";
import { Client, middleware } from "@line/bot-sdk";

const config = {
  channelSecret: process.env.LINE_CHANNEL_SECRET,
  channelAccessToken: process.env.LINE_ACCESS_TOKEN,
};

const client = new Client(config);
const app = express();

app.post("/webhook", middleware(config), async (req, res) => {
  const events = req.body.events;
  await Promise.all(events.map(handleEvent));
  res.sendStatus(200);
});

async function handleEvent(event) {
  if (event.type !== "message" || event.message.type !== "text") return;

  const userMessage = event.message.text;
  const replyText = `🔮占いBOT：あなたのメッセージ「${userMessage}」を受け取りました✨\nもう少し詳しくお聞かせください。`;

  await client.replyMessage(event.replyToken, { type: "text", text: replyText });
}

app.listen(process.env.PORT || 3000, () => console.log("Bot is running"));
